from .userCreateView import UserCreateView
from .userDetailView import UserDetailView
#from .ipsDetailView import IpsDetailView
#from .ipsCreateView import IpsCreateView
#from .ipsUpdateView import IpsUpdateView
#from .pruebatutor import pruebaluisjose
from .ipsListView import IpsList
from .ipsDetailView import IpsDetail